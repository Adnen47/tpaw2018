angular.module("app",[])
       .controller("Crl",["$scope", function($scope){
         
		//Initialiser les formulaire par les informations données dans l'énoncé de l'exercice
		document.getElementById('Entrant').value = '2';
		document.getElementById('Sortant').value = '1';
		document.getElementById('tempsEntr').value = '60';
		document.getElementById('tempsSortant').value = '90';
		document.getElementById('tempsFinal').value = '678';
		document.getElementById('persPresInit').value = '10';
		
		
		
		//Calculer le temps final de l'estimation et le nombre de personnes qui restent après un temps défini
		var b=document.getElementById('b');
 		b.onclick=resultat;
        function resultat(){
           var tempsFinal1=0;
		   var personnesReste=eval(document.getElementById('persPresInit').value) - 2;
		   for(var i=2;i<eval(document.getElementById('persPresInit').value);i++){
		       tempsFinal1 += eval(document.getElementById('tempsSortant').value);
		       presonnesReste -= 1;
		   }
		   //Afficher le temps final de l'estimation et le nombre de personnes qui restent
		   document.getElementById('tempsFinal').value = eval('tempsFinal1');
		   document.getElementById('persRestent20').value = eval('personnesReste');
        }	
		
		
		
		//stocker les informations dans un tableau
		$scope.parametres= [
            {nbPersEntrant:document.getElementById('Entrant').value, tempsEntr: document.getElementById('tempsEntr').value,
             nbPersSortant:document.getElementById('Sortant').value, tempsSortant: document.getElementById('tempsSortant').value,
             tempsFinal:document.getElementById('tempsFinal').value,
             persPresInit: document.getElementById('persPresInit').value,
			 persRestent20: document.getElementById('persRestent20').value}
        ];
		


       }]);