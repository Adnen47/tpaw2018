angular.module("app",[])
       .controller("Crl",["$scope", function($scope){
         
		
		document.getElementById('Entrant').value = '2';
		document.getElementById('Sortant').value = '1';
		document.getElementById('tempsEntr').value = '60';
		document.getElementById('tempsSortant').value = '90';
		document.getElementById('tempsFinal').value = '678';
		document.getElementById('persPresInit').value = '10';
		
		$scope.partametres= [
            {nbPersEntrant:2, temps: 60},
            {nbPersSortant:1, temps: 90},
            {tempsFinal:40*60},
            {persPresInit: 10},
			{persRestent20: 0}
        ];
		
        document.getElementById('persRestent20').value = '0';


       }]);