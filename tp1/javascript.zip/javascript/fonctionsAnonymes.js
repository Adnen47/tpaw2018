//Exemple1: Fonction anonyme
var carre=function(x){
    alert("le carré de "+x+" = "+x*x);
};
var y=prompt("Entrer un nombre");
carre(y);
//Exemple2:Fonction auto-invoquée
(function (x){
    x=prompt("Entrer un nombre");
    alert("Carre de "+x+" = "+x*x);
})();
//Exemple3: fonction normale et fonction anonyme (closure)
function compteur(){
    var i=0;
    return function(){
        return i++;
    }
}
var plusUn=compteur();
alert(plusUn()+" "+plusUn()+" "+plusUn());
