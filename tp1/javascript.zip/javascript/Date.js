alert(Date());//Afficher la date
alert(Date.now())//Afficher le nombre de seconde
//new Date
d=new Date();
alert("the time:"+d.getTime());
alert("the year is:"+d.getFullYear());
alert("the month is:"+d.getMonth()+1);
alert("date:"+d.getDate());
alert("heures:"+d.getHours());
alert("Minutes:"+d.getMinutes());
alert("secondes:"+d.getSeconds());
alert("Millisecondes:"+d.getMilliseconds());
alert("year:"+d.setFullYear(2015,5,15));
alert("Hours:"+d.setHours(12));
alert("Minutes:"+d.setMinutes(30));
alert("Secondes:"+d.setSecondes(15));
