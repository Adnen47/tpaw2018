x=Math.random()*100;
alert("x="+x);
alert("la partie entière de x est:"+Math.round(x));
alert("min de x est:"+Math.floor(x));
alert("max de x est:"+Math.ceil(x));
alert("nombre plus petit est:"+Math.min(0,-10,200,75,25));
alert("nombre max est:"+Math.max(0,-10,200,75,25));
a=5,b=7;
alert("valeur absolue:"+Math.abs(a));
alert("puissance:"+Math.pow(a,b));
alert("racine carré:"+Math.sqrt(x));
alert("cosinus de 5:"+Math.cos(a)+" et sinus de 5:"+Math.sin(a));
alert("PI = "+Math.PI);

