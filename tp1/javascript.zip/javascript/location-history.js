
alert("History arrière: "+history.back());
alert("History avant: "+history.forward());
alert("History spécifique: "+history.go(-3));
alert("History longueur: "+history.length);

location.assign("http://pierre-giraud.com");
location.reload();
location.replace("http://google.fr");
alert("location.href: "+location.href);
alert("location.pathname: "+location.pathname);