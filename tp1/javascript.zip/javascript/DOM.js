var newPara=document.createElement('p');
newPara.id='nouveau';
var texte=document.createTextNode('texte inséré');
newPara.appendChild(texte);
document.body.appendChild(newPara);

var tableau=document.getElementsByTagName('p');
alert(tableau.length);

var tableau1=document.getElementsByClassName('para');
alert(tableau1.length);

var lien=document.querySelector('a');
alert(lien);

var titre=document.getElementById('gros_titre').innerHTML;
alert(titre);

var titre1=document.getElementById('gros_titre').TextContent;
alert(titre1);

document.querySelector('a').href='http://wikipedia.org';

document.getElementById('gros_titre').style.color='orange';
document.querySelector('.para').parentNode.style.color='blue';
//document.getElementById('gros_titre').style.fontSize('40px');

var titre=document.getElementById('gros_titre');
var parent=document.body;
parent.removeChild(titre);

document.body.replaceChild(document.createElement('h2'),document.getElementById('gros_titre'));

var titre2=document.title;
var page=document.body;
var lien1=document.link;
alert(titre2+" "+page[0]+" "+lien1[0]);