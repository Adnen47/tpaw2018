hauteur = screen.height;
alert("Hauteur: "+hauteur);
//hauteurDispo = screnn.availHeight;
langue = navigator.language;
alert("Langue: "+langue);
navigateur = navigator.appName;
alert("navigateur: "+navigateur);
version = navigator.appVersion;
alert("version: "+version);
moteur = navigator.product;
alert("moteur: "+moteur);
cookieA = navigator.cookieEnabled;
alert("cookieA: "+cookieA);
alert("Hauteur: "+hauteur+" / Langue: "+langue+
" / navigateur: "+navigateur+" / version: "+version+
" / moteur: "+moteur+" / cookieA: "+cookieA);

loc = navigator.geolocation;
alert("Coordonnées:"+loc.getCurrentPosition(coordonnees));
function coordonnees(x){
para.innerHTML;
'Latitude:' +x.coords.latitude+ 
'<br>longitude:'+x.coords.longitude;
};