//propagation des événements
var p=document.querySelector('h1');
p.addEventListener('click',Message);
function Message(event){
    this.innerHTML=event.target+'<br>'+event.currentTarget+'<br>'+event.type;
}
//simple clique
var p1=document.querySelector('div');
p1.onclick=function(){
    this.innerHTML='<strong>Bravo!</strong>';
    this.style.color='orange';
}
//ou bien simple clique
var p2=document.querySelector('label');
p2.onclick=bravo;
function bravo(){
    this.innerHTML='<strong>Bravo!</strong>';
    this.style.color='blue';
}
//Maintenir le clique sur le label avec foncion anonyme
p2.addEventListener('mousedown',function(){
    this.innerHTML='<strong>vous avez cliqué sur le lien!</strong>';
    this.style.BackgroundColor='orange';
});
//ou bien simple clique
var p3=document.querySelector('form');
p3.addEventListener('click',changeTexte);
function changeTexte(){
    this.innerHTML='<strong>Bravo!</strong>';
    this.style.color='green';
}
//ou bien passer la souris avec fonction anonyme
var p4=document.querySelector('a');
p4.addEventListener('mouseover',function(){
    this.innerHTML='<strong>Bravo!</strong>';
    this.style.color='red';
});
//on peut aussi utiliser les attributs mouseout et mouseup
