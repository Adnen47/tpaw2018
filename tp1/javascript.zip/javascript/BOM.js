var ouvrir=document.getElementById('Ouvrir');
var retailler=document.getElementById('Resize');
var fermer=document.getElementById('Fermer');
var f1='';

ouvrir.addEventListener('click',fOuvrir);
retailler.addEventListener('click',fResize);
fermer.addEventListener('click',fFermer);

function fOuvrir(){
  f1=window.open('http://pierre-giraud.com','_blank','width=500, height=300');
}

function fResize(){
    f1.resizeTo(250,250);
}

function fFermer(){
  f1.close();
}