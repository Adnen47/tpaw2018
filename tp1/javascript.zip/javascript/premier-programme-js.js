//Concaténation
alert("Bienvenue "+"Monsieur "+"Ahmed");
//Constructeur
function Identite (p,n,a){
    this.prenom=p;
    this.nom=n;
    this.age=a;
}
var pierre= new Identite("Pierre","Giraud",25);
alert("l'age de "+pierre.prenom+" est:"+pierre.age);
//chercher dans une chaine
ch="Pierre Giraud";
//k=ch.indexof('a',1);//chercher 'a' dans la chaine à partir du premier caractère
//alert ("le caractère 'a' se trouve dans la position numéro "+k);
//remplacer une chaine
ch.replace("Giraud","Dupont");
alert("la nouvelle chaine est: "+ch);
//sélectionner une partie d'une chaine
ch1=ch.slice(0,6);
alert (ch1);
//Supprimer les espaces inutiles
ch2="    Bonjour    Monsieur        Paul    Lopez";
ch2.trim();
alert(ch2);
//Convertir un nombre à une chaine
x=10.4531;
ch3=x.toString();
alert("la chaine est:"+ch3);
// afficher le nombre décimal 2 chiffres après la virgule
a=x.toFixed(2);
alert("le nombre décimal 2 chiffres après la virgule de "+x+ "est:" +a);
// afficher les 3 premiers chiffre d'un nombre
b=x.toPrecision(3);
alert("les 3 premiers chiffre de "+x+" est:"+b);
// afficher l'exponentiel
e=x.toExponential(2);
alert("l'exponentiel de "+x+" est:"+e);
//Afficher la partie décimale de x
d=parseFloat(x);
alert("la partie décimale de "+x+" est:"+d);
//Afficher la partie entière de x
c=parseInt(x);
alert("la partie entière de "+x+ "est:"+c);
