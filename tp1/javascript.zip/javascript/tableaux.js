var prenoms=['Pierre','Victor','Julien','Claire'];
alert(prenoms[2]);
//Ajouter un prénom au tableau
prenoms[prenoms.length]='Daniel';
//tableau associatif
var prenoms_associatif={prenom1:'Pierre', prenom2:'Victor', prenom3:'Julien', prenom4:'Claire'};
for(var clefs in prenoms_associatif){
    alert(clefs+':'+prenoms_associatif[clefs]+'\n');
}
//Ajouter et supprimer un élément à la fin du tableau
taille=prenoms.push('Florien','Chloé');
alert(prenoms[prenoms.length]);
supp=prenoms.pop();
alert(prenoms[prenoms.length]);
//Ajouter et supprimer un élément au début d'un tableau
taille=prenoms.unshift('Florien','Chloé');
alert(prenoms[0]);
supp=prenoms.shift();
alert(prenoms[0]);
//supprimer des éléments à partir d'une position
prenoms.splice(1,3);
alert(prenoms[0]);
//trier le tableau
prenoms.sort();
alert(prenoms);
//inverser les éléments du tableau
prenoms.reverse();
alert(prenoms);
//ajouter des séparateurs au tableau
prenoms.join('/');
alert(prenoms);
//lire les éléments du tableau sélectionnés
alert(prenoms.slice(0,2));
//concaténer 2 tableau
//prenoms_associatif.concat(prenoms,prenoms1);
//alert(prenoms1);