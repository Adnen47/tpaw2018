

 function reste(texte) {
     document.getElementById('nombre_nom').innerHTML=texte.length+' car';

                        }

  function reste1(texte1) {
    document.getElementById('nombre_prenom').innerHTML=texte1.length+' car';
                       
                                               }






